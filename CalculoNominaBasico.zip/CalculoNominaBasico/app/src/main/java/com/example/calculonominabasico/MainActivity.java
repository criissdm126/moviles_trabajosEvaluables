package com.example.calculonominabasico;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText txtdias, txthoras;
    private Button btnCalcular, btnBorrar;
    private TextView lblpago, lbldescuento;
    private CheckBox ckbPago, ckbdescuento;
    private RadioGroup rdbgroupRound;
    private RadioButton rdbRedondeo, rdbNoredondeo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txthoras = (EditText) findViewById(R.id.txtHoras);
        txtdias = (EditText) findViewById(R.id.txtHoras);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);
        btnBorrar = (Button) findViewById(R.id.btnBorrar);
        lblpago = (TextView) findViewById(R.id.lblpago);
        lbldescuento = (TextView) findViewById(R.id.lbldescuento);
        ckbPago = (CheckBox)findViewById(R.id.ckbPago);
        ckbdescuento = (CheckBox) findViewById(R.id.ckbDescuento);
        rdbgroupRound = (RadioGroup) findViewById(R.id.rdbgroupRound);
        rdbRedondeo = (RadioButton) findViewById(R.id.rdbRedondeo);
        rdbNoredondeo = (RadioButton) findViewById(R.id.rdbNoredondeo);
    }

    public void  Calcular(View view){
        int dias = Integer.parseInt(txtdias.getText().toString());
        int horas = Integer.parseInt(txthoras.getText().toString());
        int horas_mensuales = horas*dias;
        Double pago = horas_mensuales*13.75;
        Double descuento = 0.00;
        Double sueldobase = 2200.00;

        if (ckbPago.isChecked() == true){
            lblpago.setText(String.valueOf(pago));
        }
        if (ckbdescuento.isChecked() == true && pago > 2200){
            descuento = pago-(pago*0.1);
            lbldescuento.setText(String.valueOf(descuento));
        }
        if(rdbgroupRound.getCheckedRadioButtonId() == R.id.rdbRedondeo){
            int pago_redondeo = (int) Math.round(pago);
            lblpago.setText(String.valueOf(pago_redondeo));
            int descuento_redondeo = (int)  Math.round(descuento);
            lbldescuento.setText(String.valueOf(descuento_redondeo));
        }
    }

    public void Borrar(View view){
        txtdias.setText("");
        txthoras.setText("");
        ckbPago.setChecked(false);
        ckbdescuento.setChecked(false);
        lblpago.setText("Pago");
        lbldescuento.setText("Con descuento");
        rdbRedondeo.setChecked(false);
        rdbNoredondeo.setChecked(false);
    }





}